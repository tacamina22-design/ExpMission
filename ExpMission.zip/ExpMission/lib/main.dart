// lib/main.dart
import 'dart:async';
import 'package:flutter/material.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:uuid/uuid.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:timezone/data/latest_all.dart' as tzdata;
import 'package:timezone/timezone.dart' as tz;

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Hive.initFlutter();
  await Hive.openBox('expBox');
  await Hive.openBox('missionsBox');

  // timezone init for notifications
  tzdata.initializeTimeZones();
  tz.setLocalLocation(tz.getLocation(DateTime.now().timeZoneName));

  runApp(ExpMissionApp());
}

// Simple data models stored as maps in Hive for prototype.

class ExpMissionApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'ExpMission',
      theme: ThemeData.light().copyWith(
        useMaterial3: false,
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.blue),
      ),
      home: HomePage(),
    );
  }
}

class HomePage extends StatefulWidget {
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final expBox = Hive.box('expBox');
  final missionsBox = Hive.box('missionsBox');

  int exp = 0;
  int level = 1;
  final int baseExpPerLevel = 100;
  int streak = 0; // consecutive days
  DateTime? lastActionDate;
  FlutterLocalNotificationsPlugin? flnp;

  @override
  void initState() {
    super.initState();
    _loadState();
    _initNotifications();
    _ensureDefaultMissions();
  }

  Future<void> _initNotifications() async {
    flnp = FlutterLocalNotificationsPlugin();
    const androidInit = AndroidInitializationSettings('@mipmap/ic_launcher');
    const iOSInit = DarwinInitializationSettings();
    await flnp!.initialize(const InitializationSettings(android: androidInit, iOS: iOSInit));
    // schedule a daily reminder default 08:00
    _scheduleDailyReminder(Time(8, 0, 0));
  }

  Future<void> _scheduleDailyReminder(Time t) async {
    final androidDetails = AndroidNotificationDetails('expmission_daily', 'Daily Reminder', channelDescription: 'Nhắc làm nhiệm vụ hàng ngày', importance: Importance.max);
    final iosDetails = DarwinNotificationDetails();
    await flnp!.zonedSchedule(
      0,
      'Nhắc ExpMission',
      'Đừng quên hoàn thành nhiệm vụ hôm nay!',
      _nextInstanceOfTime(t),
      NotificationDetails(android: androidDetails, iOS: iosDetails),
      uiLocalNotificationDateInterpretation: UILocalNotificationDateInterpretation.absoluteTime,
      androidAllowWhileIdle: true,
      matchDateTimeComponents: DateTimeComponents.time,
    );
  }

  tz.TZDateTime _nextInstanceOfTime(Time t) {
    final now = tz.TZDateTime.now(tz.local);
    var scheduled = tz.TZDateTime(tz.local, now.year, now.month, now.day, t.hour, t.minute, t.second);
    if (scheduled.isBefore(now)) scheduled = scheduled.add(Duration(days: 1));
    return scheduled;
  }

  Future<void> _loadState() async {
    setState(() {
      exp = expBox.get('exp', defaultValue: 0);
      level = expBox.get('level', defaultValue: 1);
      streak = expBox.get('streak', defaultValue: 0);
      final lastMillis = expBox.get('lastAction', defaultValue: null);
      lastActionDate = lastMillis != null ? DateTime.fromMillisecondsSinceEpoch(lastMillis) : null;
    });
  }

  Future<void> _ensureDefaultMissions() async {
    if (missionsBox.isEmpty) {
      _addMissionLocal('Hoàn thành nhiệm vụ đầu tiên', 'Chào mừng! Hoàn thành để nhận EXP cơ bản.', 20);
      _addMissionLocal('Đọc 10 trang sách', 'Nhiệm vụ mẫu', 30);
      // Add a timed quest and a boss quest prototype
      _addMissionLocal('Timed: Viết nhật ký 15 phút', 'Timed|15', 50);
      _addMissionLocal('Boss: Tiêu diệt Golem Hoang Tàn (3 bước)', 'Boss|3', 200);
    }
  }

  void _addMissionLocal(String title, String meta, int reward) {
    final id = Uuid().v4();
    missionsBox.put(id, {
      'id': id,
      'title': title,
      'meta': meta,
      'reward': reward,
      'done': false,
      'created': DateTime.now().millisecondsSinceEpoch,
    });
  }

  int expToNextLevel() => level * baseExpPerLevel;

  void _addExp(int amount, {bool isStreakBonus = false}) {
    setState(() {
      int gained = amount;
      final doubleMultiplier = expBox.get('expMultiplier', defaultValue: 1.0);
      gained = (gained * doubleMultiplier).round();

      exp += gained;
      // level up loop
      while (exp >= expToNextLevel()) {
        exp -= expToNextLevel();
        level++;
        _showLevelUpDialog(level);
      }
      // update streak: if lastAction is yesterday or today
      _updateStreak();
      expBox.put('exp', exp);
      expBox.put('level', level);
    });
  }

  void _updateStreak() {
    final now = DateTime.now();
    if (lastActionDate == null) {
      streak = 1;
    } else {
      final diff = now.difference(lastActionDate!).inDays;
      if (diff == 0) {
        // same day, don't increment streak
      } else if (diff == 1) {
        streak += 1;
      } else {
        streak = 1;
      }
    }
    lastActionDate = now;
    expBox.put('streak', streak);
    expBox.put('lastAction', now.millisecondsSinceEpoch);
    // optional: apply streak bonus when hitting milestone
    if (streak % 7 == 0) {
      // weekly big bonus
      _addExp(50);
    }
  }

  void _showLevelUpDialog(int newLevel) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: Text('Level Up!'),
        content: Text('Bạn đã đạt Level $newLevel — mở khóa kỹ năng mới!'),
        actions: [TextButton(onPressed: () => Navigator.pop(context), child: Text('OK'))],
      ),
    );
  }

  List<Map> _missionsList() {
    return missionsBox.values.cast<Map>().toList().cast<Map>();
  }

  void _completeMission(String id) {
    final item = Map<String, dynamic>.from(missionsBox.get(id));
    if (item['done'] == true) return;
    item['done'] = true;
    item['doneAt'] = DateTime.now().millisecondsSinceEpoch;
    missionsBox.put(id, item);
    int reward = item['reward'] ?? 0;
    final String meta = item['meta'] ?? '';
    if (meta.startsWith('Timed')) {
      reward = (reward * 1.5).round();
    }
    if (meta.startsWith('Boss')) {
      reward = (reward * 2).round();
    }
    _addExp(reward);
    // record history
    List history = expBox.get('history', defaultValue: []);
    history.add({'when': DateTime.now().toIso8601String(), 'action': 'Complete mission', 'title': item['title'], 'exp': reward});
    expBox.put('history', history);
  }

  void _resetData() {
    expBox.clear();
    missionsBox.clear();
    _loadState();
    _ensureDefaultMissions();
    setState(() {});
  }

  // Simple UI for prototype
  @override
  Widget build(BuildContext context) {
    final progress = exp / expToNextLevel();
    return Scaffold(
      appBar: AppBar(
        title: Text('ExpMission'),
        actions: [
          IconButton(onPressed: () => _showHistory(), icon: Icon(Icons.history)),
          IconButton(onPressed: () {
            showDialog(context: context, builder: (_) => AlertDialog(
              title: Text('Reset dữ liệu?'),
              actions: [
                TextButton(onPressed: () { Navigator.pop(context); }, child: Text('Hủy')),
                TextButton(onPressed: () { Navigator.pop(context); _resetData(); }, child: Text('Xác nhận')),
              ],
            ));
          }, icon: Icon(Icons.refresh))
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(14.0),
        child: Column(
          children: [
            Text('Level: $level', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
            SizedBox(height: 6),
            LinearProgressIndicator(value: progress),
            SizedBox(height: 6),
            Text('EXP: $exp / ${expToNextLevel()}'),
            SizedBox(height: 8),
            Text('Streak: $streak ngày liên tiếp', style: TextStyle(fontSize: 12, color: Colors.grey[700])),
            SizedBox(height: 12),
            Expanded(child: _missionsView()),
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () => _showAddMissionDialog(),
        child: Icon(Icons.add),
      ),
    );
  }

  Widget _missionsView() {
    final list = _missionsList();
    if (list.isEmpty) return Center(child: Text('Không có nhiệm vụ'));
    return ListView.separated(
      itemCount: list.length,
      separatorBuilder: (_, __) => Divider(),
      itemBuilder: (context, idx) {
        final m = Map.from(list[idx]);
        final done = m['done'] == true;
        return ListTile(
          title: Text(m['title'] ?? ''),
          subtitle: Text('${m['meta'] ?? ''} • ${m['reward']} EXP'),
          trailing: done ? Icon(Icons.check, color: Colors.green) : ElevatedButton(
            child: Text('Hoàn thành'),
            onPressed: () => _completeMission(m['id']),
          ),
        );
      },
    );
  }

  void _showAddMissionDialog() {
    final titleCtl = TextEditingController();
    final rewardCtl = TextEditingController(text: '20');
    final metaCtl = TextEditingController();
    showDialog(context: context, builder: (_) => AlertDialog(
      title: Text('Thêm nhiệm vụ'),
      content: Column(mainAxisSize: MainAxisSize.min, children: [
        TextField(controller: titleCtl, decoration: InputDecoration(labelText: 'Tiêu đề')),
        TextField(controller: metaCtl, decoration: InputDecoration(labelText: 'Meta (e.g. Timed|15 or Boss|3)')),
        TextField(controller: rewardCtl, decoration: InputDecoration(labelText: 'EXP'), keyboardType: TextInputType.number),
      ]),
      actions: [
        TextButton(onPressed: () => Navigator.pop(context), child: Text('Hủy')),
        TextButton(onPressed: () {
          final t = titleCtl.text.trim();
          final r = int.tryParse(rewardCtl.text) ?? 20;
          final meta = metaCtl.text.trim();
          if (t.isNotEmpty) _addMissionLocal(t, meta.isEmpty ? 'Normal' : meta, r);
          Navigator.pop(context);
          setState(() {});
        }, child: Text('Thêm')),
      ],
    ));
  }

  void _showHistory() {
    final history = expBox.get('history', defaultValue: []);
    showModalBottomSheet(context: context, builder: (_) => ListView.builder(
      itemCount: history.length,
      itemBuilder: (context, i) {
        final h = history[i];
        return ListTile(title: Text(h['action'] ?? ''), subtitle: Text('${h['title'] ?? ''} — ${h['exp']} EXP • ${h['when']}'));
      },
    ));
  }
}